
const fs = require("fs");

const Product = require("../models/property");

let mongoose = require("mongoose");

exports.getArea = async (req, res, next) => {
  // let brandList = [];
  let arr = [];
  
  try {
   

    let dist = 10 * 1000;
    let dat2 = "";

    let data0;
    let area = await Area1.find().lean();
    await Promise.all(
      area.map(async (t1) => {
        let lat1 = t1.location.coordinates[0];
        let lon1 = t1.location.coordinates[1];

        let lat2 = req.body.longitude;
        let lon2 = req.body.latitude;

        function getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
          var R = 6371; // Radius of the earth in km
          var dLat = deg2rad(lat2 - lat1); // deg2rad below
          var dLon = deg2rad(lon2 - lon1);
          var a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(deg2rad(lat1)) *
              Math.cos(deg2rad(lat2)) *
              Math.sin(dLon / 2) *
              Math.sin(dLon / 2);
          var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
          var d = R * c; // Distance in km
          return d;
        }
        function deg2rad(deg) {
          return deg * (Math.PI / 180);
        }

        let data = getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2).toFixed(1);

        if (10 >= data) {
          console.log("valueeee", data);
          let vendor = await vendorbussiness
            .find({ area_id: t1._id })
            .then(async (dat3) => {
              dat3.map(async (dat5) => {
                // await Product.find({ vendor_id: dat5.vendor_id })
                //   .then((daa) => {
                //     // console.log('daa',daa)
                //     arr.push(daa);
                //   })
                //   .then((dddd) => {
                //     // console.log('dddddd',arr)
                //   });
                // // console.log('dat5',dat5)

                if (dat5.vendor_id) {
                  data0 = await Product.find({
                    vendor_id: dat5.vendor_id,
                  }).lean()
                  .populate("category_id")
                  .lean()
                  .populate("brand_id")
                  .lean()
                  .populate("vendor_id")
                  .lean()
                  await Promise.all(
                    data0.map((t9) => {
                      console.log("asdd", t9);
                      arr.push(t9);
                    })
                  );
                  // console.log('test2222',arr)
                  res.json({
                    message: "fetch data successfully",
                    data: arr,
                  });

                  //                       if (resd.length) {
                  //                         resd.map(t1=>{

                  //                           arr.push(t1);

                  //                         })
                }
              });
            });
          //                 // console.log('data1111',dat3[1])
          //                 dat3.map(async (dat5) => {
          //                   // await Product.find({vendor_id:dat5.vendor_id}).then(daa=>{
          //                   //   // console.log('daa',daa)
          //                   //   arr.push(daa)
          //                   // }).then(dddd=>{
          //                   //   console.log('dddddd',arr)

          //                   // })
          //                   // console.log('dat5',dat5)

          //                   if(dat5.vendor_id){

          //                     data0 = await Product.find({ vendor_id: dat5.vendor_id })
          //                     .then(async(resd) => {

          //                       if (resd.length) {
          //                         resd.map(t1=>{

          //                           arr.push(t1);

          //                         })

          //                         // console.log('resd',arr)

          //                       }
          //                     })

          //                   }

          //                 });
          //               });
          //           }
          //         } //if
        }
      })
    );

    //  let area = await Area1.find().then(async (post) => {
    //     // await Promise.all(
    //       let t6=await Promise.all(
    //       post.map(async (dat) => {
    //         if (dat) {
    //           let lat1 = dat.location.coordinates[0];
    //           let lon1 = dat.location.coordinates[1];

    //           let lat2 = req.body.longitude;
    //           let lon2 = req.body.latitude;

    //           function getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
    //             var R = 6371; // Radius of the earth in km
    //             var dLat = deg2rad(lat2 - lat1); // deg2rad below
    //             var dLon = deg2rad(lon2 - lon1);
    //             var a =
    //               Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    //               Math.cos(deg2rad(lat1)) *
    //                 Math.cos(deg2rad(lat2)) *
    //                 Math.sin(dLon / 2) *
    //                 Math.sin(dLon / 2);
    //             var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    //             var d = R * c; // Distance in km
    //             return d;
    //           }
    //           function deg2rad(deg) {
    //             return deg * (Math.PI / 180);
    //           }

    //           let data = getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2).toFixed(
    //             1
    //           );
    //           if (10 >= data) {
    //             console.log('valueeee',dat)

    //             let vendor = await vendorbussiness
    //               .find({ area_id: dat._id })
    //               .then(async (dat3) => {
    //                 // console.log('data1111',dat3[1])
    //                 dat3.map(async (dat5) => {
    //                   // await Product.find({vendor_id:dat5.vendor_id}).then(daa=>{
    //                   //   // console.log('daa',daa)
    //                   //   arr.push(daa)
    //                   // }).then(dddd=>{
    //                   //   console.log('dddddd',arr)

    //                   // })
    //                   // console.log('dat5',dat5)

    //                   if(dat5.vendor_id){

    //                     data0 = await Product.find({ vendor_id: dat5.vendor_id })
    //                     .then(async(resd) => {

    //                       if (resd.length) {
    //                         resd.map(t1=>{

    //                           arr.push(t1);

    //                         })

    //                         // console.log('resd',arr)

    //                       }
    //                     })

    //                   }

    //                 });
    //               });
    //           }
    //         } //if

    //         // dat.location.coordinates.map(dat12=>{
    //         //   console.log('dat1',dat12);

    //         // console.log('data',arr)

    //         // })
    //       })
    //     // );

    //       )

    //     //  getDistanceFromLatLonInKm(lat1,lon1,lat2,lon2).toFixed(1)
    //   }); //first

    //   // console.log('t11',data0)
    //   console.log('t112',arr)
    //   await Promise.all(t6)

    //   console.log('t112',arr)

    // console.log('t11',arr)
    //   setTimeout(() => {
    //     res.json({
    //       message:"fetch successfully",
    //           data: arr
    //     })
    //   }, 2000);

    //const maxDistance = parseFloat(req.query.maxDistance);
    // const options = {near :[longitude,latitude],maxDistance:10000}
    // Area.find({

    //   location: {
    //     $near : {

    //       $geometry : {
    //         type : 'Point',
    //         coordinates:[24.913142, 67.089761],
    //         spherical: true
    //       },
    //       $maxDistance: 1000
    //     }
    //   }
    // }).find((error,results)=>{
    //   if (error) console.log(error);
    // //console.log(JSON.stringify(results, 0, 2));
    // res.status(200).json({
    //   message:"fetch successfully",
    //   data: results
    // }

    // )

    // });
    //  });
    // Area.find({
    // location: {
    //   $near: {
    //       $maxDistance: 1150,
    //       $geometry: {
    //           type: 'Point',
    //           coordinates: [24.913320, 67.090428]
    //       }
    //   }
    // }
    // }, function (err, result) {
    // if (err) {
    //   return console.log(err);
    // }

    // res.json({
    //   message:"fetch successfully",
    //       data: result
    // })

    // });

    // Area.where('location').near({
    //   center: {
    //       type: 'Point',
    //       // coordinates: [24.913142, 67.089761]
    //       coordinates: [24.913320, 67.090428]
    //   },

    //   // Converting meters to miles
    //   maxDistance: 10/111.12,
    //   spherical: true
    // }).find((error,results)=>{
    //     if (error) console.log(error);
    //   //console.log(JSON.stringify(results, 0, 2));
    //   res.status(200).json({
    //     message:"fetch successfully",
    //     data: results
    //   }

    //   )

    //   });

    // Area.find({
    //   location: {
    //     $near: {
    //       $maxDistance: 100/111.12, // 100km
    //       $geometry: {
    //         type: "Point",
    //         coordinates: [67.0970916, 24.9180271] // [lon, lat]
    //       }
    //     }
    //   }
    // }).exec(res => console.log(res));

    // var query = Area.find({'type':'Point'});

    // // ...include filter by Max Distance
    // if (distance) {

    //     // Using MongoDB's geospatial querying features.
    //     query = query.where('geo.coordinates').near({
    //         center: {
    //             type: 'Point',
    //             coordinates: [lat, long]
    //         },

    //         // Converting meters to miles
    //         maxDistance: distance * 1609.34,
    //         spherical: true
    //     });
    // }

    // // Execute Query and Return the Query Results
    // query.exec(function(err, geoObjects) {
    //     if (err)
    //         res.send(err);

    //     // If no errors, respond with a JSON
    //     res.json(geoObjects);
    // });

    // try {
    //   const product = await Product.findById(desID).populate("vendor_id");

    //   console.log("product", product.is_view);
    //   Product.findOneAndUpdate(
    //     { _id: product._id },
    //     { $inc: { is_view: 1 } },
    //     { new: true }
    //   )
    //     .then((result) => {
    //       console.log("updated");
    //     })
    //     .catch((err) => console.log(err));

    //   const data = await Product.findById(desID)
    //     .populate("category_id")
    //     .populate("vendor_id")
    //     .populate("brand_id")
    //     .exec((err, result) => {
    //       if (err) {
    //         res.json({
    //           success: false,
    //           message: "Product data is not found",
    //         });
    //       } else {
    //         if (result) {
    //           res.json({
    //             success: true,
    //             data: result,
    //           });
    //         }
    //       }
    //     });

    // } catch (error) {}
  } catch (error) {}
};

exports.getProductInfobySearch = async(req, res, next) => {

  
  // let data1 = req.body.data;
  let arr=[];
  let property_type=req.body.property_type;
  let title=req.body.title;
  let min_price=req.body.min_price;
  let max_price=req.body.max_price;
  let bedrooms=req.body.bedrooms;
  let bathrooms=req.body.bathrooms;
  let floor_size=req.body.floor_size;
  let erf_size=req.body.erf_size;
  let pet_friendly=req.body.pet_friendly;
  let garden=req.body.garden;
  let pool=req.body.pool;
  let flatlet=req.body.flatlet;
  let retirement=req.body.retirement;
  let repossessed=req.body.repossessed;
  let on_show=req.body.on_show;
  let auction=req.body.auction;

  console.log(req.body);

  let data=await Product.find({$or: [{property_type : { $in : property_type}},{title:title},{min_price:min_price},{max_price:max_price},{bedrooms:bedrooms},{bathrooms:bathrooms}]})
  .then(t1=>{
    res.json({
      message:"fatch the data successfully",
      data:t1
    })
  })
 
};

  exports.getProduct = async (req, res, next) => {
    


    let arr = [];
  console.log("d1")
  
      let data = await Product.find().lean();
      // console.log(data)
      if (data.length) {
        await Promise.all(
          data.map(async (post) => {
            // console.log("result", post._id);
            let data2 = await Product.findById(post._id)
              .populate("category_id")
              .lean()
              .populate("brand_id")
              .lean()
              .populate("vendor_id")
              .lean();
            arr.push(data2);
          })
        );

        res.status(200).json({
          message: "Product Data Fetch Successfully",
          data: arr,
        });
        
     
      } else {
        res.status(400).json({
          message: "Product Data Fetch Failed",
        });
      }
    
      
    
  };


exports.getProductimg = (req, res, next) => {

    var img = fs.readFileSync("public/propertyad/" + req.params.img);
    res.writeHead(200, { "Content-Type": "image/gif" });
    res.end(img, "binary");
    // let cat='data';
    // res.send(".public\photo-1200px-node.js_logo.svg.png")
  
};

exports.addProduct = (req, res, next) => {
  let cat;

  let reqFiles = [];

  const url = req.protocol + "://" + req.get("host");
  console.log(req.files);
  if(req.files['photo']){
  
   
     for (var i = 0; i < req.files['photo'].length; i++) {
       reqFiles = [];
      reqFiles.push(url + '/property/getimg/' + req.files['photo'][i].filename)
     //  const reqFiles = req.files && req.files['photo']&& req.files['photo'].length ? [] : '';
     
      }
     }
     
  const reqfile = req.files && req.files['customer_photo']&& req.files['customer_photo'].length ? []:'';


 
  
// req.files && req.files['photo']&& req.files['photo'].length && reqFiles.push(url + '/category/getimg/' +req.files['photo'][0].filename)
 req.files && req.files['customer_photo'] &&req.files['customer_photo'].length && reqfile.push(url + '/property/getimg/' + req.files['customer_photo'][0].filename)


  try {
 
  
      cat = new Product({
        _id: new mongoose.Types.ObjectId(),
        title: req.body.title,
        description: req.body.description,
        property_type : req.body.property_type,
        minprice: req.body.minprice,
        maxprice: req.body.maxprice,
        photo: reqFiles,
        bedrooms: req.body.bedrooms,
        bathrooms : req.body.bathrooms ,
        parking: req.body.parking,
        floor_size: req.body.floor_size,
        erf_size: req.body.erf_size,
        pet_friendly:req.body.pet_friendly, 
        garden:req.body.garden,
        pool:req.body.pool,
        retirement:req.body.retirement,
        on_show:req.body.on_show,
        auction:req.body.auction,
        garden:req.body.garden,
        location:req.body.location,
        name:req.body.name,
        customer_photo:reqfile,
        phone_number:req.body.phone_number,
        price: req.body.price,
      });

      console.log("cat if", cat);
      cat.save().then((result) => {
        console.log(result);

        res.status(200).json({
          message: "Product created successfully!",
          data: cat,
        });
      });
    }
    // }
   catch (err) {
    console.log(err);
    res.json({
      message: "Product data created failed!",
      data: err,
    });
  }
};

exports.editProduct = async (req, res, next) => {

  let reqFiles =  '';
  const url = req.protocol + '://' + req.get('host')
  console.log("req.File22",req.files)
  if(req.files['photo']){
    
   console.log("req.File221",req.body)

    
  
    for (var i = 0; i < req.files['photo'].length; i++) {
      reqFiles = [];
     reqFiles.push(url + '/property/getimg/' + req.files['photo'][i].fieldname)
    //  const reqFiles = req.files && req.files['photo']&& req.files['photo'].length ? [] : '';
    
     }
    }
    
  const reqfile = req.files && req.files['customer_photo']&& req.files['customer_photo'].length ? []:'';


 
  
// req.files && req.files['photo']&& req.files['photo'].length && reqFiles.push(url + '/category/getimg/' +req.files['photo'][0].filename)
 req.files && req.files['customer_photo'] &&req.files['customer_photo'].length && reqfile.push(url + '/property/getimg/' + req.files['customer_photo'][0].fieldname)

    
  let params;
  if (req.body.stockandVariety == "false") {
    params = {
      title: req.body.title,
        description: req.body.description,
        property_type : req.body.property_type,
        minprice: req.body.minprice,
        maxprice: req.body.maxprice,
        photo: reqFiles,
        bedrooms: req.body.bedrooms,
        bathrooms : req.body.bathrooms ,
        parking: req.body.parking,
        floor_size: req.body.floor_size,
        erf_size: req.body.erf_size,
        pet_friendly:req.body.pet_friendly, 
        garden:req.body.garden,
        pool:req.body.pool,
        retirement:req.body.retirement,
        on_show:req.body.on_show,
        auction:req.body.auction,
        garden:req.body.garden,
        location:req.body.location,
        name:req.body.name,
        customer_photo:reqfile,
        number:req.body.number,
        price: req.body.price,



    };

    console.log("params", params);
    for (let prop in params) if (!params[prop]) delete params[prop];
    console.log("params", params);
  
    const depID = req.params.id;

    Product.findOneAndUpdate({ _id: depID }, params).then((data1) => {
      res.json({
        message: "Product Updated successfully",
      
      });
    })
  } else {
    params = {
      category_id: req.body.category_id,
      title: req.body.title,
      description: req.body.description,
      meta_description: req.body.meta_description,
      meta_title: req.body.meta_title,
      photo: reqFiles,
      brand_id: req.body.brand_id,
      long_description: req.body.long_description,
      care: req.body.care,
      weight: req.body.weight,
      quantity: 0,
      price: 0,
      discount_price: 0,
      slug: req.body.slug,
      vendor_id: req.body.vendor_id,
      is_Active: req.body.is_Active,
      insidebox: req.body.insidebox,
      attribute_feature:req.body.attribute_feature,
      stockandVariety: req.body.stockandVariety,
    };
    console.log("params", params);
    for (let prop in params) if (!params[prop]) delete params[prop];
    console.log("params", params);
  
    const depID = req.params.id;
  
    const data = await Stock.find({
      product_id: depID,
    }).exec(async (err, result) => {
      if (err) {
        res.json({
          success: false,
          message: "Product data  not found",
        });
      } else {
        console.log("result", result);
  
        let att = req.body.attribute_id;
  
        let arr = [];
        if (result && result.length) {
          if (att && att.length > 0) {
            JSON.parse(att).map((data) => {
              if (data.data.length) {
                let a = [];
                let name;
                data.data.map((attr) => {
                  a.push(attr.label.toLowerCase());
                  name = attr.p_name.toLowerCase();
                });
  
                arr.push({ [name]: a });
              }
            });
            console.log("---------", arr);
  
            var keys = arr.map((o) => Object.keys(o)[0]); //Get the list of keys
            var myResult = arr
              .map((o) => Object.values(o)[0])
              .reduce((c, v) =>
                [].concat(...c.map((o) => v.map((x) => [].concat(o, x))))
              ) //Make all possible combinations
              .map((o) =>
                o.reduce(
                  (c, v, i) =>
                    Object.assign(c, {
                      [keys[i]]: v,
                      price: 0,
                      discount: 0,
                      from: "",
                      to: "",
                    }),
                  {}
                )
              ); //Construct the final format
  
            Stock.findOneAndUpdate({ _id: result[0]._id }, { data: myResult })
              .then((result) => {
                Product.findOneAndUpdate({ _id: depID }, params).then((data1) => {
                  res.json({
                    message: " Product Updated successfully",
                    data: myResult,
                  });
                });
              })
              .catch((err) => console.log(err));
  
            // const dep = new Stock({
            //   product_id: depID,
            //   data: result,
            // });
          } else {
            console.log("update--------------");
            Stock.findOneAndRemove({ _id: result[0]._id }).then((result) => {
              Product.findOneAndUpdate({ _id: depID }, params).then((data1) => {
                res.json({
                  message: " Product Updated successfully",
                  data: myResult,
                });
              });
            });
          }
        } else {
          if (att && att.length > 0) {
            JSON.parse(att).map((data) => {
              if (data.data.length) {
                let a = [];
                let name;
                data.data.map((attr) => {
                  a.push(attr.label.toLowerCase());
                  name = attr.p_name.toLowerCase();
                });
  
                arr.push({ [name]: a });
              }
            });
            console.log("---------", arr);
  
            var keys = arr.map((o) => Object.keys(o)[0]); //Get the list of keys
            var result = arr
              .map((o) => Object.values(o)[0])
              .reduce((c, v) =>
                [].concat(...c.map((o) => v.map((x) => [].concat(o, x))))
              ) //Make all possible combinations
              .map((o) =>
                o.reduce(
                  (c, v, i) =>
                    Object.assign(c, {
                      [keys[i]]: v,
                      price: 0,
                      discount: 0,
                      from: "",
                      to: "",
                    }),
                  {}
                )
              );
  
            console.log("*****************", result);
  
            const dep = new Stock({
              product_id: depID,
              data: result,
            });
            dep.save().then((result) => {
              Product.findOneAndUpdate({ _id: depID }, params).then((data1) => {
                res.json({
                  message: " Product Updated successfully",
                });
              });
              // res.json({
              //   message: "Product data created successfully!",
              //   success: true,
              //   data: cat,
              // });
            });
          } else {
            console.log("update--------------");
            Product.findOneAndUpdate({ _id: depID }, params).then((data1) => {
              res.json({
                message: " Product Updated successfully",
              });
            });
          }
        }
      }
    });
  }
      // if (result.length) {
      //   let oldData = [];
      //   console.log('************************',result);
      //   result.map( res => {
      //     // res.data.map()
      //     oldData = res.data;
      //     console.log(res);
      //   })

      //   let att = req.body.attribute_id;
      //   let arr = [];
      //   if(att.length>0){
      //     JSON.parse(att).map((data) => {
      //       if (data.data.length) {
      //         let a = [];
      //         let name;
      //         data.data.map((attr) => {
      //           a.push(attr.label.toLowerCase());
      //           name = attr.p_name.toLowerCase();
      //         });

      //         arr.push({ [name]: a });
      //       }
      //     });
      //     console.log("---------", arr);

      //     var keys = arr.map((o) => Object.keys(o)[0]);
      //     var result = arr
      //       .map((o) => Object.values(o)[0])
      //       .reduce((c, v) =>
      //         [].concat(...c.map((o) => v.map((x) => [].concat(o, x))))
      //       )
      //       .map((o) =>
      //         o.reduce((c, v, i) => Object.assign(c, { [keys[i]]: v,price: 0,
      //                     discount: 0,
      //                     from: "",
      //                     to: "", }), {})
      //       );
      //   }

      //   if (JSON.stringify(oldData) !== JSON.stringify(result)) {
      //     let newData = []

      //     // await Promise.all( oldData.map(old => {
      //     //   let filter = result.filter(re => JSON.stringify(re) === JSON.stringify(old));
      //     //   if (filter.length) {
      //     //     newData.push(old)
      //     //   }
      //     //   // console.log(old);
      //     // }))

      //     // for (let i = 0; i < oldData.length; i++) {
      //     //   for (let j = 0; j < result.length; j++) {

      //     //     console.log('oldData-----------------',oldData[i]);
      //     //     console.log('result-----------------',result[j]);
      //     //   }
      //     // }

      //     // await Promise.all( result.map(old => {
      //     //   let filter2 = oldData.filter(re => JSON.stringify(Object.keys(re)) === JSON.stringify(Object.keys(old)) );
      //     //   if (filter2.length) {
      //     //     console.log('---++++++++',filter2);
      //     //     let filter = oldData.filter(re => JSON.stringify(re) === JSON.stringify(old));
      //     //     if (filter.length) {
      //     //       newData.push(old);
      //     //     }
      //     //   }else{

      //     //   }
      //     //   // console.log(old);
      //     // }))

      //     // await Promise.all( oldData.map(old => {
      //     //   let filter = oldData.filter(re => JSON.stringify(re) === JSON.stringify(old));
      //     //   if (filter.length) {
      //     //     newData.push(old);
      //     //   }
      //     //   // console.log(old);
      //     // }))

      //     console.log('----------------notsame',newData);
      //   }

      // } else {

      //   let att = req.body.attribute_id;
      //   let arr = [];
      //   if(att.length>0){
      //     JSON.parse(att).map((data) => {
      //       if (data.data.length) {
      //         let a = [];
      //         let name;
      //         data.data.map((attr) => {
      //           a.push(attr.label.toLowerCase());
      //           name = attr.p_name.toLowerCase();
      //         });

      //         arr.push({ [name]: a });
      //       }
      //     });
      //     console.log("---------", arr);

      //     var keys = arr.map((o) => Object.keys(o)[0]);
      //     var result = arr
      //       .map((o) => Object.values(o)[0])
      //       .reduce((c, v) =>
      //         [].concat(...c.map((o) => v.map((x) => [].concat(o, x))))
      //       )
      //       .map((o) =>
      //         o.reduce((c, v, i) => Object.assign(c, { [keys[i]]: v,price: 0,
      //                     discount: 0,
      //                     from: "",
      //                     to: "", }), {})
      //       );

      //     console.log("*****************", result);

      //     const dep = new Stock({
      //       product_id: depID,
      //       data: result,
      //     });

      //     dep.save().then((result) => {
      //           res.json({
      //             message: "Product Updated Successfully"
      //           });
      //         })

      //   }

      // }
    

  // Product.findOneAndUpdate(
  //   { _id: req.params.id },

  //   params
  // )
  //   .then((result) => {
  //     res.json({
  //       message: "Updated successfully",
  //       data: result,
  //     });
  //   })
  //   .catch((err) => console.log(err));
};
exports.deleteProduct = (req, res, next) => {
  const depID = req.params.id;

  Product.findByIdAndRemove(depID).then((result) => {
    if (!result) {
      const error = new HttpError("could not find post", 404);
      console.log(error);
      return next(error);
    }
    res.send({
      message: "deleted  successfully",
      result: result,
    });
  });
};
